package com.cg.grocery.exceptions;

public class CustomerDetailsNotFoundException extends Exception{

}
