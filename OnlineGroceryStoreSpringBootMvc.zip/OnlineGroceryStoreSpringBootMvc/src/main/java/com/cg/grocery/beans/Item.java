package com.cg.grocery.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
@Entity
public class Item {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="itemCodeGenerator")
	@SequenceGenerator(name="itemCodeGenerator",initialValue=101)
	private int itemCode;
	private String itemName;
	private int noOfUnits;
	private int orderUnits;
	private int price;
	private int weight;
	@ManyToOne
	private Order order;
	
	
	public Item() {
		super();
	}
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getNoOfUnits() {
		return noOfUnits;
	}
	public void setNoOfUnits(int noOfUnits) {
		this.noOfUnits = noOfUnits;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public Item(int itemCode, String itemName, int noOfUnits, int price, int weight, Order order) {
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.noOfUnits = noOfUnits;
		this.price = price;
		this.weight = weight;
		this.order = order;
	}
	@Override
	public String toString() {
		return "Item [itemCode=" + itemCode + ", itemName=" + itemName + ", noOfUnits=" + noOfUnits + ", price=" + price
				+ ", weight=" + weight + ", order=" + order + "]";
	}
	@Override
	public boolean equals(Object arg0) {
		// TODO Auto-generated method stub
		return super.equals(arg0);
	}
	
	
	

}
