package com.cg.flight.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.flight.beans.Booking;

public interface BookingDAO extends JpaRepository<Booking, Integer> {

}
