package com.cg.flight.beans;

public enum BookingStatus {
	CONFIRMED,
	CANCELLED,
	PAYMENT_PENDING
}
