package com.cg.flight.beans;

public enum FlightStatus {
	ACTIVE,
	CANCELLED
}
