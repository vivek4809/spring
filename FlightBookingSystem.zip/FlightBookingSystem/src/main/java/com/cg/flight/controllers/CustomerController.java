package com.cg.flight.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.flight.beans.Customer;
import com.cg.flight.beans.Flight;
import com.cg.flight.exceptions.BookingServicesDownException;
import com.cg.flight.exceptions.CustomerDetailsNotFoundException;
import com.cg.flight.exceptions.FlightDetailsNotFoundException;
import com.cg.flight.services.BookingServices;


@Controller
public class CustomerController {
	@Autowired
	private BookingServices bookingServices;


	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid @ModelAttribute Customer customer,
			BindingResult result){
		try {
			if(result.hasErrors())
				return new ModelAndView("registrationPage");
			ModelAndView model = new ModelAndView("registrationPage");
			customer = bookingServices.acceptCustomerDetails(customer);
			model.addObject("message", "customer details added successfully. Your customer Id is: "+customer.getCustomerID());
			return model;
		} catch (BookingServicesDownException e) {
			return new ModelAndView("registrationPage", "message", e.getMessage());
		}
	}
	@RequestMapping("customerDetails")
	public ModelAndView customerDetailsAction(@Valid@ModelAttribute Customer customer,
			BindingResult result) {
		try {
			ModelAndView model = new ModelAndView("getCustomerDetailsPage");
			customer=bookingServices.retrieveUserDetails(customer.getCustomerID());
			model.addObject("flag",1);
			model.addObject("customer", customer);
			return model;
		} catch (CustomerDetailsNotFoundException | BookingServicesDownException e) {
			return new ModelAndView("getCustomerDetailsPage", "message", e.getMessage());
		}
	}
	@RequestMapping("/allCustomerDetails")
	public ModelAndView allCustomerDetailsAction(@Valid @ModelAttribute Customer customer,
			BindingResult result) {
		try {
			ModelAndView model = new ModelAndView("getAllCustomerDetailsPage");
			List<Customer> customers;
			customers = bookingServices.getAllCustomers();
			model.addObject("flag",1);
			model.addObject("customers", customers);
			return model;
		} catch (BookingServicesDownException e) {
			return new ModelAndView("getAllCustomerDetailsPage", "message", e.getMessage());
		}
	}
	@RequestMapping("addFlightDetails")
	public ModelAndView addFlightDetailsAction(@Valid@ModelAttribute Flight flight,
			BindingResult result) {
		try {
			if(result.hasErrors())
				return new ModelAndView("addFlightDetailsPage");
			ModelAndView model = new ModelAndView("addFlightDetailsPage");		
			flight = bookingServices.getFlightDetails(flight);
			model.addObject("message", "Flight details added successfully");
			return model;			 
		} catch (BookingServicesDownException e) {
			return new ModelAndView("addFlightDetailsPage", "message", e.getMessage());
		}
	}
	@RequestMapping("flightDetails")
	public ModelAndView flightDetailsAction(@Valid@ModelAttribute Flight flight,
			BindingResult result) {
		try {
			ModelAndView model = new ModelAndView("getFlightDetailsPage");		
			flight=bookingServices.retrieveFlightDetails(flight.getFlightCode());
			model.addObject("flag",1);
			model.addObject("flight", flight);
			return model;
		} catch (FlightDetailsNotFoundException | BookingServicesDownException e) {
			return new ModelAndView("getFlightDetailsPage", "message", e.getMessage());
		}
	}
	@RequestMapping("/allFlightDetails")
	public ModelAndView allFlightDetailsAction(@Valid @ModelAttribute Flight flight,
			BindingResult result) {
		try {
			ModelAndView model = new ModelAndView("getAllFlightDetailsPage");
			List<Flight> flights;			
			flights = bookingServices.getAllFlightDetails();
			model.addObject("flag",1);
			model.addObject("flights", flights);
			return model;
		} catch (BookingServicesDownException e) {
			return new ModelAndView("getAllFlightDetailsPage", "message", e.getMessage());
		}
	}
}
