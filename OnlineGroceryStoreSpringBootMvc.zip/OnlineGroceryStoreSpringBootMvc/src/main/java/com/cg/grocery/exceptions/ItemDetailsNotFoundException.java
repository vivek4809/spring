package com.cg.grocery.exceptions;

public class ItemDetailsNotFoundException extends Exception {

}
