package com.cg.flight.exceptions;

public class CustomerDetailsNotFoundException extends Exception {

	public CustomerDetailsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerDetailsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public CustomerDetailsNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CustomerDetailsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CustomerDetailsNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
