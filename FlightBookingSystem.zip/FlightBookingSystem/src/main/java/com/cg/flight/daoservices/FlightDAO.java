package com.cg.flight.daoservices;

import javax.print.DocFlavor.STRING;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.flight.beans.Flight;

public interface FlightDAO extends JpaRepository<Flight, String> {

}
