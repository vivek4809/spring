package com.cg.grocery.exceptions;

public class ItemsNotAvailableException  {

}
