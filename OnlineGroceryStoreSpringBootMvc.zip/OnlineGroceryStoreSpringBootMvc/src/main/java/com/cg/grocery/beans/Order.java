package com.cg.grocery.beans;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
@Entity
public class Order {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="orderIdGenerator")
	@SequenceGenerator(name="orderIdGenerator",initialValue=1001)
	private long orderId;
	private LocalDate orderDate;
	
	@OneToMany
	private List<Item> items;
	@OneToOne
	private Transaction transaction;
	@ManyToOne
	private Customer customer;
	public Order() {
		super();
	}
	public Order(long orderId, LocalDate orderDate, List<Item> items, Transaction transaction,
			Customer customer) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
	
		this.items = items;
		this.transaction = transaction;
		this.customer = customer;
	}
	public long getOrderId() {
		return orderId;
	}
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
	public LocalDate getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public List<Item> getItems() {
		return items;
	}
	public void setItems(List<Item> items) {
		this.items = items;
	}
	public Transaction getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderDate=" + orderDate +  ", items="
				+ items + ", transaction=" + transaction + ", customer=" + customer + "]";
	}
	@Override
	public boolean equals(Object arg0) {
		// TODO Auto-generated method stub
		return super.equals(arg0);
	}
	
	
	
	
}
