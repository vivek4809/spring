package com.cg.flight.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.flight.beans.Customer;
import com.cg.flight.beans.Flight;
import com.cg.flight.services.BookingServices;




@Controller
public class URIController {
	Customer customer;
	Flight flight;
	@Autowired
	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping("/registration")
	public String getRegistrationPage() {
		return "registrationPage";
	}
	@RequestMapping("/index")
	public String getHomePage() {
		return "indexPage";
	}	
	@RequestMapping("/getCustomerDetails")
	public String getCustomerDetailsPage() {
		return "getCustomerDetailsPage";
	}
	@RequestMapping("/getAllCustomerDetails")
	public String getAllCustomerDetailsPage() {
		return "getAllCustomerDetailsPage";
	}
	@RequestMapping("/registerFlight")
	public String registerFlightPage() {
		return "addFlightDetailsPage";
	}
	@RequestMapping("/getFlightDetails")
	public String getFlightDetailsPage() {
		return "getFlightDetailsPage";
	}
	@RequestMapping("/getAllFlightDetails")
	public String getAllFlightDetailsPage() {
		return "getAllFlightDetailsPage";
	}
	@ModelAttribute
	public Customer getCustomer() {
		customer=new Customer();
		return customer;
	}	
	@ModelAttribute
	public Flight getFlight() {
		flight=new Flight();
		return flight;
	}
}
