package com.cg.grocery.services;

import java.util.List;

import com.cg.grocery.beans.Customer;
import com.cg.grocery.beans.Item;
import com.cg.grocery.beans.Order;
import com.cg.grocery.beans.Transaction;
import com.cg.grocery.exceptions.CustomerDetailsNotFoundException;
import com.cg.grocery.exceptions.OrderDetailsNotFoundException;
import com.cg.grocery.exceptions.ServicesDownException;

public interface GroceryServices {
	
	long acceptCustomerDetails(Customer customer) throws ServicesDownException;
	
	int acceptNewItems(Item item) throws ServicesDownException;
	
	Customer getCustomerDetails(long customerId) throws CustomerDetailsNotFoundException;
	
	List<Customer> getAllCustomersDetails();
	
	List<Item> getAllItems();
	
	Item getSpecificItemDetails(int itemCode);
	
	 Order acceptOrderDetails
	
	Order getOrderDetails(long orderId);
	
	List<Item> itemsPurchasedInSpecificOrder(long customerId,long orderId)  throws CustomerDetailsNotFoundException,OrderDetailsNotFoundException;
	
	List<Order> orderDetailsForCustomer(long customerId) throws CustomerDetailsNotFoundException;
	
	List<Item> allItemsForCustomer(long customerId) throws CustomerDetailsNotFoundException;
	
	Transaction prepareBill(long customerId,long orderId) throws CustomerDetailsNotFoundException,OrderDetailsNotFoundException;
	
	float getBill()
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
