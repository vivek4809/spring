package com.cg.project.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GmailLoginStepDefinition {


@Given("^User is on Gmail Login Page$")
public void user_is_on_Gmail_Login_Page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions

}

@When("^User Entered the correct credentials$")
public void user_Entered_the_correct_credentials() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
  
}

@Then("^User must go to Inbox Page$")
public void user_must_go_to_Inbox_Page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions

}
	
}
