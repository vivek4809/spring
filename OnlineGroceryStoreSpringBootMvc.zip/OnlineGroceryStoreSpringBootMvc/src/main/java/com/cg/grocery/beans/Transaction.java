package com.cg.grocery.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import org.hibernate.cache.spi.support.AbstractReadWriteAccess.Item;

@Entity
public class Transaction {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="transactionIdGenerator")
	@SequenceGenerator(name="transactionIdGenerator",initialValue=10012456)
	private Long transactionId;
	private float price;
	@OneToOne
	private Order order;
	@ManyToOne
	private Customer customer;
	public Transaction() {
		super();
	}
	public Transaction(Long transactionId, float price, Order order, Customer customer) {
		super();
		this.transactionId = transactionId;
		this.price = price;
		this.order = order;
		this.customer = customer;
	}
	public Long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", price=" + price + ", order=" + order + ", customer="
				+ customer + "]";
	}
	@Override
	public boolean equals(Object arg0) {
		// TODO Auto-generated method stub
		return super.equals(arg0);
	}
	
	
	}
