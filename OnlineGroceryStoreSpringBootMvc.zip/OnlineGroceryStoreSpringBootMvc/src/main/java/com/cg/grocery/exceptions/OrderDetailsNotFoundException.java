package com.cg.grocery.exceptions;

public class OrderDetailsNotFoundException extends Exception {

}
