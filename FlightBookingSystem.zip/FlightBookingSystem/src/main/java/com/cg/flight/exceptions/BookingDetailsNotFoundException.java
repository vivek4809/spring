package com.cg.flight.exceptions;

public class BookingDetailsNotFoundException extends Exception{

	public BookingDetailsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookingDetailsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public BookingDetailsNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BookingDetailsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BookingDetailsNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
