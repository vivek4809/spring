package com.cg.flight.exceptions;

public class FlightDetailsNotFoundException extends Exception {

	public FlightDetailsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FlightDetailsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public FlightDetailsNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public FlightDetailsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FlightDetailsNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
