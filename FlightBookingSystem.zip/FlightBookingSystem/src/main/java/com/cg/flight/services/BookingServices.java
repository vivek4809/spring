package com.cg.flight.services;

import java.util.List;

import com.cg.flight.beans.Booking;
import com.cg.flight.beans.Flight;
import com.cg.flight.exceptions.BookingServicesDownException;
import com.cg.flight.exceptions.CustomerDetailsNotFoundException;
import com.cg.flight.exceptions.FlightDetailsNotFoundException;
import com.cg.flight.beans.Customer;

public interface BookingServices {

	public Customer acceptCustomerDetails(Customer customer) throws BookingServicesDownException;
	
	public Customer retrieveUserDetails(int customerID) throws CustomerDetailsNotFoundException,BookingServicesDownException;
	
	public List<Customer> getAllCustomers() throws BookingServicesDownException;
	
	public Flight getFlightDetails(Flight flight) throws BookingServicesDownException;
	
	public Flight retrieveFlightDetails(String flightCode) throws FlightDetailsNotFoundException,BookingServicesDownException;
	
	public List<Flight> getAllFlightDetails() throws BookingServicesDownException;
	
	public Booking addUserBooking(Booking booking);
 	
}
