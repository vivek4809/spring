package com.cg.flight.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Flight {
	@Id
	private String flightCode;
	private String flightName, flightCompany;
	@Enumerated(EnumType.STRING)
	private FlightStatus status;
	@OneToMany(mappedBy="flight")
	private List<Booking> bookings;
	public Flight() {
		super();
	}
	public Flight(String flightCode, String flightName, String flightCompany, FlightStatus status,
			List<Booking> bookings) {
		super();
		this.flightCode = flightCode;
		this.flightName = flightName;
		this.flightCompany = flightCompany;
		this.status = status;
		this.bookings = bookings;
	}
	public String getFlightCode() {
		return flightCode;
	}
	public void setFlightCode(String flightCode) {
		this.flightCode = flightCode;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getFlightCompany() {
		return flightCompany;
	}
	public void setFlightCompany(String flightCompany) {
		this.flightCompany = flightCompany;
	}
	public FlightStatus getStatus() {
		return status;
	}
	public void setStatus(FlightStatus status) {
		this.status = status;
	}
	public List<Booking> getBookings() {
		return bookings;
	}
	public void setBookings(List<Booking> bookings) {
		this.bookings = bookings;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bookings == null) ? 0 : bookings.hashCode());
		result = prime * result + ((flightCode == null) ? 0 : flightCode.hashCode());
		result = prime * result + ((flightCompany == null) ? 0 : flightCompany.hashCode());
		result = prime * result + ((flightName == null) ? 0 : flightName.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Flight other = (Flight) obj;
		if (bookings == null) {
			if (other.bookings != null)
				return false;
		} else if (!bookings.equals(other.bookings))
			return false;
		if (flightCode == null) {
			if (other.flightCode != null)
				return false;
		} else if (!flightCode.equals(other.flightCode))
			return false;
		if (flightCompany == null) {
			if (other.flightCompany != null)
				return false;
		} else if (!flightCompany.equals(other.flightCompany))
			return false;
		if (flightName == null) {
			if (other.flightName != null)
				return false;
		} else if (!flightName.equals(other.flightName))
			return false;
		if (status != other.status)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Flight [flightCode=" + flightCode + ", flightName=" + flightName + ", flightCompany=" + flightCompany
				+ ", status=" + status + ", bookings=" + bookings + "]";
	}
	
}
