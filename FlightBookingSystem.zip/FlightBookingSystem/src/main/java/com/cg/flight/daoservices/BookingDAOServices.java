package com.cg.flight.daoservices;

public interface BookingDAOServices {

}
