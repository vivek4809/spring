package com.cg.grocery.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.grocery.beans.Item;

public interface ItemDAO extends JpaRepository<Item, Integer>{

}
