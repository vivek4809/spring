package com.cg.flight.exceptions;

public class BookingServicesDownException extends Exception{

	public BookingServicesDownException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookingServicesDownException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public BookingServicesDownException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public BookingServicesDownException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public BookingServicesDownException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
