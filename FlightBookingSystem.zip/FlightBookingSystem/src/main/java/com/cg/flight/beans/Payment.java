package com.cg.flight.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Payment {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="paymentIDGenerator")
	@SequenceGenerator(name="paymentIDGenerator", initialValue=101, allocationSize=0)
	private int paymentID;
	private String paymentMedium;
	private PaymentStatus paymentStatus;
	@OneToOne
	private Booking booking;
	@ManyToOne
	private Customer customer;
	public Payment() {
		super();
	}
	public Payment(int paymentID, String paymentMedium, PaymentStatus paymentStatus, Booking booking, Customer customer) {
		super();
		this.paymentID = paymentID;
		this.paymentMedium = paymentMedium;
		this.paymentStatus = paymentStatus;
		this.booking = booking;
		this.customer = customer;
	}
	public int getPaymentID() {
		return paymentID;
	}
	public void setPaymentID(int paymentID) {
		this.paymentID = paymentID;
	}
	public String getPaymentMedium() {
		return paymentMedium;
	}
	public void setPaymentMedium(String paymentMedium) {
		this.paymentMedium = paymentMedium;
	}
	public PaymentStatus getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(PaymentStatus paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public Booking getBooking() {
		return booking;
	}
	public void setBooking(Booking booking) {
		this.booking = booking;
	}
	public Customer getUser() {
		return customer;
	}
	public void setUser(Customer customer) {
		this.customer = customer;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((booking == null) ? 0 : booking.hashCode());
		result = prime * result + paymentID;
		result = prime * result + ((paymentMedium == null) ? 0 : paymentMedium.hashCode());
		result = prime * result + ((paymentStatus == null) ? 0 : paymentStatus.hashCode());
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Payment other = (Payment) obj;
		if (booking == null) {
			if (other.booking != null)
				return false;
		} else if (!booking.equals(other.booking))
			return false;
		if (paymentID != other.paymentID)
			return false;
		if (paymentMedium == null) {
			if (other.paymentMedium != null)
				return false;
		} else if (!paymentMedium.equals(other.paymentMedium))
			return false;
		if (paymentStatus != other.paymentStatus)
			return false;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Payment [paymentID=" + paymentID + ", paymentMedium=" + paymentMedium + ", paymentStatus="
				+ paymentStatus + ", booking=" + booking + ", user=" + customer + "]";
	}
	
}
