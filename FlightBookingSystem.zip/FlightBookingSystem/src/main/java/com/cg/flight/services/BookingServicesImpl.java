package com.cg.flight.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.flight.beans.Booking;
import com.cg.flight.beans.Flight;
import com.cg.flight.beans.Customer;
import com.cg.flight.daoservices.BookingDAO;
import com.cg.flight.daoservices.FlightDAO;
import com.cg.flight.daoservices.PaymentDAO;
import com.cg.flight.exceptions.BookingServicesDownException;
import com.cg.flight.exceptions.CustomerDetailsNotFoundException;
import com.cg.flight.exceptions.FlightDetailsNotFoundException;
import com.cg.flight.daoservices.CustomerDAO;
@Component("bookingServices")
public class BookingServicesImpl implements BookingServices {
	@Autowired
	private BookingDAO bookingDAO;
	@Autowired
	private FlightDAO flightDAO;
	@Autowired
	private PaymentDAO paymentDAO;
	@Autowired
	private CustomerDAO customerDAO;

	@Override
	public Customer acceptCustomerDetails(Customer customer) throws BookingServicesDownException{
		customer=customerDAO.save(customer);
		return customer;
	}

	@Override
	public Customer retrieveUserDetails(int customerID)  throws CustomerDetailsNotFoundException,BookingServicesDownException{
		return customerDAO.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("No Customer Details Found!"));

	}

	@Override
	public List<Customer> getAllCustomers() throws BookingServicesDownException{
		return customerDAO.findAll();
	}

	@Override
	public Flight getFlightDetails(Flight flight) throws BookingServicesDownException {
		return flightDAO.save(flight);
	}

	@Override
	public Flight retrieveFlightDetails(String flightCode) throws FlightDetailsNotFoundException,BookingServicesDownException {
		return flightDAO.findById(flightCode).orElseThrow(()->
		new FlightDetailsNotFoundException("No Flight Details Found!"));
	}

	@Override
	public List<Flight> getAllFlightDetails() throws BookingServicesDownException{
		return flightDAO.findAll();
	}

	@Override
	public Booking addUserBooking(Booking booking) {
		// TODO Auto-generated method stub
		return null;
	}

}
