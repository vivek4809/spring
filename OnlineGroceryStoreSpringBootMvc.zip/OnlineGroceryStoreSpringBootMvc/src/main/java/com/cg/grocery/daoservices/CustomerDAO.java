package com.cg.grocery.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.grocery.beans.Customer;

public interface CustomerDAO extends JpaRepository<Customer,Integer>{

}
