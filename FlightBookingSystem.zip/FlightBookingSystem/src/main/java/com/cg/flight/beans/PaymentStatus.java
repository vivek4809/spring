package com.cg.flight.beans;

public enum PaymentStatus {
	PAYMENT_PENDING,
	PAYMENT_DONE
}
