package com.cg.flight.beans;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
@Entity
/*@Table(
		uniqueConstraints= {@UniqueConstraint(columnNames = {"seatNumber", "flight" })})*/
public class Booking {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="bookingIDGenerator")
	@SequenceGenerator(name="bookingIDGenerator", initialValue=10001, allocationSize=0)
	private int bookingID;
	private String sourceCity, destinationCity, seatNumber;
	private Date departureTime, arrivalTime;
	@Enumerated(EnumType.STRING)
	private BookingStatus bookingStatus;
	@ManyToOne
	private Customer customer;
	@ManyToOne//(mappedBy="bookings")
	private Flight flight;
	@OneToOne(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="booking")
	private Payment payment;
	public Booking() {
		super();
	}
	public Booking(int bookingID, String sourceCity, String destinationCity, String seatNumber, Date departureTime,
			Date arrivalTime, BookingStatus bookingStatus, Customer user, Flight flight, Payment payment) {
		super();
		this.bookingID = bookingID;
		this.sourceCity = sourceCity;
		this.destinationCity = destinationCity;
		this.seatNumber = seatNumber;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.bookingStatus = bookingStatus;
		this.customer = user;
		this.flight = flight;
		this.payment = payment;
	}
	public int getBookingID() {
		return bookingID;
	}
	public void setBookingID(int bookingID) {
		this.bookingID = bookingID;
	}
	public String getSourceCity() {
		return sourceCity;
	}
	public void setSourceCity(String sourceCity) {
		this.sourceCity = sourceCity;
	}
	public String getDestinationCity() {
		return destinationCity;
	}
	public void setDestinationCity(String destinationCity) {
		this.destinationCity = destinationCity;
	}
	public String getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}
	public Date getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(Date departureTime) {
		this.departureTime = departureTime;
	}
	public Date getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(Date arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public BookingStatus getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(BookingStatus bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	public Customer getUser() {
		return customer;
	}
	public void setUser(Customer customer) {
		this.customer = customer;
	}
	public Flight getFlight() {
		return flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	public Payment getPayment() {
		return payment;
	}
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((arrivalTime == null) ? 0 : arrivalTime.hashCode());
		result = prime * result + bookingID;
		result = prime * result + ((bookingStatus == null) ? 0 : bookingStatus.hashCode());
		result = prime * result + ((departureTime == null) ? 0 : departureTime.hashCode());
		result = prime * result + ((destinationCity == null) ? 0 : destinationCity.hashCode());
		result = prime * result + ((flight == null) ? 0 : flight.hashCode());
		result = prime * result + ((payment == null) ? 0 : payment.hashCode());
		result = prime * result + ((seatNumber == null) ? 0 : seatNumber.hashCode());
		result = prime * result + ((sourceCity == null) ? 0 : sourceCity.hashCode());
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Booking other = (Booking) obj;
		if (arrivalTime == null) {
			if (other.arrivalTime != null)
				return false;
		} else if (!arrivalTime.equals(other.arrivalTime))
			return false;
		if (bookingID != other.bookingID)
			return false;
		if (bookingStatus != other.bookingStatus)
			return false;
		if (departureTime == null) {
			if (other.departureTime != null)
				return false;
		} else if (!departureTime.equals(other.departureTime))
			return false;
		if (destinationCity == null) {
			if (other.destinationCity != null)
				return false;
		} else if (!destinationCity.equals(other.destinationCity))
			return false;
		if (flight == null) {
			if (other.flight != null)
				return false;
		} else if (!flight.equals(other.flight))
			return false;
		if (payment == null) {
			if (other.payment != null)
				return false;
		} else if (!payment.equals(other.payment))
			return false;
		if (seatNumber == null) {
			if (other.seatNumber != null)
				return false;
		} else if (!seatNumber.equals(other.seatNumber))
			return false;
		if (sourceCity == null) {
			if (other.sourceCity != null)
				return false;
		} else if (!sourceCity.equals(other.sourceCity))
			return false;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Booking [bookingID=" + bookingID + ", sourceCity=" + sourceCity + ", destinationCity=" + destinationCity
				+ ", seatNumber=" + seatNumber + ", departureTime=" + departureTime + ", arrivalTime=" + arrivalTime
				+ ", bookingStatus=" + bookingStatus + ", user=" + customer + ", flight=" + flight + ", payment=" + payment
				+ "]";
	}
	
}
