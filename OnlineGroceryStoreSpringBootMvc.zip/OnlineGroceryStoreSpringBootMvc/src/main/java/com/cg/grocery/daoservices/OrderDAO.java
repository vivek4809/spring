package com.cg.grocery.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.grocery.beans.Order;

public interface OrderDAO extends JpaRepository<Order, Integer> {

}
