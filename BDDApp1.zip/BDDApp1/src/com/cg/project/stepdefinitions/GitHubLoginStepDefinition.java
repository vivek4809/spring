package com.cg.project.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.pagebeans.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class GitHubLoginStepDefinition {
	WebDriver driver;
	private LoginPage loginPage;
	
	@Given("^User is on the Github loginPage$")
	public void user_is_on_the_Github_loginPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("https://github.com/login");
		loginPage=PageFactory.initElements(driver, LoginPage.class);
		
	}
	@When("^User entered its credentials and click Submit$")
	public void user_entered_its_credentials_and_click_Submit() throws Throwable {
/*	  By by=By.name("login");
	  WebElement searchTxt = driver.findElement(by);
	  searchTxt.sendKeys("vivek4809");
	
	   by = By.name("password");
	 searchTxt = driver.findElement(by);
	  searchTxt.sendKeys("Vivek@4809");
	  searchTxt.submit();*/
		loginPage.setUsername("vivek4809");
		loginPage.setPassword("Vivek@4809");
		loginPage.clickSignIn();
	}

	@Then("^User should Navigate to his home page$")
	public void user_should_Navigate_to_his_home_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="GitHub";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();  
	}

	@When("^User entered its incorrect credentials and click Submit$")
	public void user_entered_its_incorrect_credentials_and_click_Submit() throws Throwable {
		  By by=By.name("login");
		  WebElement searchTxt = driver.findElement(by);
		  searchTxt.sendKeys("vivek4809");
		 
		  by = By.name("password");
		   searchTxt = driver.findElement(by);
		  searchTxt.sendKeys("Vivek@1234");
		  searchTxt.submit();
	}

	@Then("^User should remain on signIn page$")
	public void user_should_remain_on_signIn_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Sign in to GitHub � GitHub";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();  
	}

}
