package com.cg.flight.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.flight.beans.Customer;

public interface CustomerDAO extends JpaRepository<Customer, Integer> {

}
